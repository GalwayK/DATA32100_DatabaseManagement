SELECT * FROM prc.donation;

SELECT * FROM prc.volunteer;

SELECT * FROM prc.address;

SELECT * FROM datamart.fact_donation;

SELECT * FROM datamart.dim_donor;

SELECT * FROM datamart.dim_volunteer;

SELECT * FROM datamart.dim_address;

SELECT * FROM datamart.dim_donation_date;

SELECT * FROM datamart.donations_date_view;

SELECT * FROM datamart.donations_hierarchy_view;

SELECT * FROM datamart.donations_volunteers_view;
