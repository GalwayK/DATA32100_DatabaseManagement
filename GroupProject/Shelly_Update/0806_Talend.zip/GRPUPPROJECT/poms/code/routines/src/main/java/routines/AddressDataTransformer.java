package routines;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

/*
 * user specification: the function's comment should contain keys as follows: 1. write about the function's comment.but
 * it must be before the "{talendTypes}" key.
 * 
 * 2. {talendTypes} 's value must be talend Type, it is required . its value should be one of: String, char | Character,
 * long | Long, int | Integer, boolean | Boolean, byte | Byte, Date, double | Double, float | Float, Object, short |
 * Short
 * 
 * 3. {Category} define a category for the Function. it is required. its value is user-defined .
 * 
 * 4. {param} 's format is: {param} <type>[(<default value or closed list values>)] <name>[ : <comment>]
 * 
 * <type> 's value should be one of: string, int, list, double, object, boolean, long, char, date. <name>'s value is the
 * Function's parameter name. the {param} is optional. so if you the Function without the parameters. the {param} don't
 * added. you can have many parameters for the Function.
 * 
 * 5. {example} gives a example for the Function. it is optional.
 */
public class AddressDataTransformer {
	
    /**
     * getTitlecaseString: Returns input String in TitleCase
     *
     * {talendTypes} String
     *
     * {Category} User Defined
     *
     * {param} string input: String to be titleCased
     *
     */
    public static String getTitlecaseString(String strInput)
    {
    	if (strInput == null)
    	{
    		return null;
    	}
        strInput = strInput.toLowerCase();
        String strOutput = "";
        String[] arrStrings = strInput.split(" ");

        for (int i = 0; i < arrStrings.length; i++)
        {
            char charFirstLetter = arrStrings[i].charAt(0);
            char charTitleCharacter = Character.toTitleCase(charFirstLetter);

            strOutput  = String.format("%s %c%s",
                    strOutput,
                    charTitleCharacter,
                    arrStrings[i].substring(1));
        }
        return strOutput.trim();
    }

    /**
     * getAddressNumber: Returns Street Number from Address
     *
     * {talendTypes} Integer
     *
     * {Category} User Defined
     *
     * {param} string address: Complete Address String
     *
     */
    public static Integer getAddressNumber(String strAddress)
    {
        String[] arrStrings = strAddress.split(" ");
        Integer numAddress = null;
        for (int i = 0; i < arrStrings.length; i++)
        {
            try
            {
                numAddress = Integer.parseInt(arrStrings[i]);
            }
            catch (Exception ex)
            {
            }
        }
        return numAddress;
    }

    /**
     * getStreetType: Returns Street Type from Address
     *
     * {talendTypes} String
     *
     * {Category} User Defined
     *
     * {param} string address: Complete Address String
     *
     * {param} string types: String containing all street types
     *
     */
    public static String getStreetType(String strAddress, String strTypes)
    {
        List<String> listTypes = new ArrayList<String>(List.of(strTypes.split(";")));
        
        String strOutput = null;
        String[] arrStrings = strAddress.split(" ");

        for (int i = 1; i < arrStrings.length - 2; i++)
        {
            if (listTypes.contains(arrStrings[i].toUpperCase()))
            {
                strOutput = arrStrings[i].trim();;
            }
        }

        return strOutput;
    }

    /**
     * getStreetDirection: Returns Street Direction from Address
     *
     * {talendTypes} String
     *
     * {Category} User Defined
     *
     * {param} string address: Complete Address String
     *
     * {param} string directions: String containing all street direction
     *
     */
    public static String getStreetDirection(String strAddress, String strDirections)
    {
        List<String> listDirections = new ArrayList<String>(List.of(strDirections.split(";")));
        String[] arrStrings = strAddress.split(" ");
        String strOutput = null;

        for (String string : arrStrings)
        {
            if (listDirections.contains(string.toUpperCase()))
            {
                strOutput = string.trim();;
            }
        }
        return strOutput;
    }

    /**
     * getAddressProvince: Returns Province from Address
     *
     * {talendTypes} String
     *
     * {Category} User Defined
     *
     * {param} string address: Complete Address String
     *
     */
    public static String getAddressProvince(String strAddress)
    {
        String[] arrStrings = strAddress.split(" ");
        return arrStrings[arrStrings.length - 1];
    }

    /**
     * getAddressCity: Returns City from Address
     *
     * {talendTypes} String
     *
     * {Category} User Defined
     *
     * {param} string address: Complete Address String
     *
     */
    public static String getAddressCity(String strAddress)
    {
        String[] arrStrings = strAddress.split(" ");
        return arrStrings[arrStrings.length - 2];
    }

    /**
     * getStreetName: Returns Street Direction from Address
     *
     * {talendTypes} String
     *
     * {Category} User Defined
     *
     * {param} string address: Complete Address String
     *
     * {param} string types: String containing all street types
     *
     * {param} string directions: String containing all street direction
     *
     */
    public static String getStreetName(String strAddress, String strType, String strDirections)
    {
        String strDirectionsAndTypes = String.format("%s;%s", strType, strDirections);
        
        List<String> listTypesAndDirections = new ArrayList<String>(List.of(strDirectionsAndTypes.split(";")));

        String[] arrStrings = strAddress.split(" ");
        String strOutput = "";
        for (int i = 1; i < arrStrings.length - 2; i++)
        {
            strOutput = listTypesAndDirections.contains(arrStrings[i].toUpperCase())
                    ? strOutput
                    : String.format("%s %s", strOutput, arrStrings[i]);
        }
        return strOutput.trim();
    }
    
    /**
     * combineAddressDetails: Combines together Address pieces into a single String
     *
     * {talendTypes} String
     *
     * {Category} User Defined
     * 
     * {param} int number: Street Number
     *
     * {param} string address: Complete Address String
     *
     * {param} string type: String containing all street types
     *
     * {param} string direction: String containing all street direction
     * 
     * {param} string city: String of City name
     *
     * {param} string province: String of Province name
     *
     */
    public static String combineAddressDetails(int number, String address,
    		String type, String direction, String city, String province)
    {
    	type = type == null ? "" : " " + type;
    	direction = direction == null ? "" : " " + direction;
    	return String.format("%d %s%s%s %s %s", 
    			number, address, type, direction, city, province);
    }
}