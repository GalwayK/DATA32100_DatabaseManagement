package routines;

import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.Scanner;

/*
 * user specification: the function's comment should contain keys as follows: 1. write about the function's comment.but
 * it must be before the "{talendTypes}" key.
 * 
 * 2. {talendTypes} 's value must be talend Type, it is required . its value should be one of: String, char | Character,
 * long | Long, int | Integer, boolean | Boolean, byte | Byte, Date, double | Double, float | Float, Object, short |
 * Short
 * 
 * 3. {Category} define a category for the Function. it is required. its value is user-defined .
 * 
 * 4. {param} 's format is: {param} <type>[(<default value or closed list values>)] <name>[ : <comment>]
 * 
 * <type> 's value should be one of: string, int, list, double, object, boolean, long, char, date. <name>'s value is the
 * Function's parameter name. the {param} is optional. so if you the Function without the parameters. the {param} don't
 * added. you can have many parameters for the Function.
 * 
 * 5. {example} gives a example for the Function. it is optional.
 */
public class PostalCodeApiRetriever {

    public static String apiToken = "pk.eyJ1IjoiZGJhczMyMTAwMGdyb3VwcHJvamVjdCIsImEiOiJjbGtyN3VydXIwc3IwM2ZsOXJyMTUzMzkyIn0.87vImXWq8vpIwQR_BSRFQQ";
    public static String strEndpoint = "https://api.mapbox.com/geocoding/v5/mapbox.places/%s.json?country=CA&limit=1&access_token=%s";


    /**
     * getPostalCode: Retrieves postal code from API
     * 
     * {talendTypes} String
     * 
     * {Category} User Defined
     * 
     * {param} string address: The address to obtain the postal code for
     */

    public static String getPostalCode(String strAddress)
    {
    	String strReturn = null;
    	
        String strUrl = String.format(strEndpoint, strAddress, apiToken).replace(" ", "_");
        
        System.out.printf("Searching for Postal Code of Address %s...\n", strAddress);
        System.out.printf("Using URL %s...\n", strUrl);
        try
        {

            URL url = new URL(strUrl);

            HttpURLConnection connection = (HttpURLConnection) url.openConnection();
            connection.connect();

            int responseCode = connection.getResponseCode();

            if (responseCode == 200)
            {
            	System.out.println("Data found!");
                String strJSON = "";
                Scanner scanner = new Scanner(url.openStream());

                while (scanner.hasNext())
                {
                    strJSON += scanner.nextLine();
                }
                scanner.close();

//                int indexPostField = strJSON.indexOf("\"id\":\"postcode");
//
//                String strPostal = strJSON.substring(indexPostField);
//
//                int indexPostal = strPostal.indexOf("text");
//
//                String postalCode = strPostal.substring(indexPostal + 7, indexPostal + 14).trim();
                
                String strSubstringJSON = strJSON.substring(strJSON.indexOf("\"id\":\"postcode"));

                int indexPostCodeSection = strSubstringJSON.indexOf("text");

                String postalCode = strSubstringJSON.substring(indexPostCodeSection + 7, indexPostCodeSection + 14).trim();
                
                System.out.printf("Postal Code Retrieved: %s\n", postalCode);

                strReturn = postalCode;
            }
            else
            {
                System.out.printf("Response code, : %d\n", responseCode);
            }
        }
        catch (MalformedURLException ex)
        {
        	System.out.println("Error: Malformed URL");
        }
        catch (Exception ex)
        {
            System.out.println("Error: Something went wrong." + ex.toString());
        }
        System.out.println();
        return strReturn;
    }
}
